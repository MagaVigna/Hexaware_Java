package dao;
import exception.*;
import model.*;

import java.util.List;

public interface IOrderManagementRepository 
{
    void createOrder(User user, Product product, int quantity) throws UserNotFoundException, OrderNotFoundException;
    void cancelOrder(int userId, int orderId) throws UserNotFoundException, OrderNotFoundException;
    void createProduct(User user, Product product) throws UserNotFoundException;
    void createUser(User user);
    List<Product> getAllProducts();
    List<Product> getOrderByUser(User user);
    User getUserById(int userId) throws UserNotFoundException;
    Product getProductById(int productId) ;

}
