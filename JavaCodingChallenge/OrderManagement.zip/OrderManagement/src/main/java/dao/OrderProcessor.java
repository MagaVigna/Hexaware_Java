package dao;

import model.*;
import exception.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import util.DBUtil;

public class OrderProcessor implements IOrderManagementRepository {
    private Connection connection;

    
    public OrderProcessor() {
        try {
            connection = DBUtil.getDBConn();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    @Override
    public void createOrder(User user, Product product, int quantity) {
        try {
            
                String insertOrderQuery = "insert into orders (user_id, product_id, quantity) values (?, ?, ?)";
                PreparedStatement insertOrderStatement = connection.prepareStatement(insertOrderQuery);
                insertOrderStatement.setInt(1, user.getUserId());
                insertOrderStatement.setInt(2, product.getProductid());
                insertOrderStatement.setInt(3, quantity);
                insertOrderStatement.executeUpdate();
                System.out.println("Order created successfully!");
            
        } catch (SQLException e) {
            System.out.println("Error creating order: " + e.getMessage());
        }
    }


    @Override
    public void cancelOrder(int userId, int orderId) throws  OrderNotFoundException {
        try {
            String deleteOrderQuery = "delete from orders where order_id = ?";
            PreparedStatement deleteOrderStatement = connection.prepareStatement(deleteOrderQuery);
            deleteOrderStatement.setInt(1, orderId);
            int rowsAffected = deleteOrderStatement.executeUpdate();
            if (rowsAffected == 0) {
              throw new OrderNotFoundException("Order not found", orderId);
            }
             

        }
        catch (SQLException e) {
            System.out.println(e);
        }
        catch (OrderNotFoundException e) {
      	  System.out.println("Error: User with ID " + e.getOrderId() + " not found.");
    	}
     }

    @Override
    public void createProduct(User user, Product product) {
    	try {
        if (!user.getRole().equalsIgnoreCase("Admin")) {
            throw new UserNotFoundException("User is not an admin and cannot create products");
        }
    	}catch (UserNotFoundException e) {
        	  System.out.println("Error: User with ID " + user.getUserId() + " not found.");
      	}

        try {
            String insertProductQuery = "insert into product (productname, description, price, quantityinstock, type, brand, warrantyperiod, size, color) values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement insertProductStatement = connection.prepareStatement(insertProductQuery);
            insertProductStatement.setString(1, product.getProductname());
            insertProductStatement.setString(2, product.getDescription());
            insertProductStatement.setDouble(3, product.getPrice());
            insertProductStatement.setInt(4, product.getQuantityinstock());
            insertProductStatement.setString(5, product.getType());
            if (product instanceof Electronics) {
                insertProductStatement.setString(6, ((Electronics) product).getBrand());
                insertProductStatement.setInt(7, ((Electronics) product).getWarrantyPeriod());
                insertProductStatement.setNull(8, Types.VARCHAR);
                insertProductStatement.setNull(9, Types.VARCHAR);
            } else if (product instanceof Clothing) {
                insertProductStatement.setNull(6, Types.VARCHAR);
                insertProductStatement.setNull(7, Types.INTEGER);
                insertProductStatement.setString(8, ((Clothing) product).getSize());
                insertProductStatement.setString(9, ((Clothing) product).getColor());
            }
            insertProductStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
        
        
    }
    @Override
    public void createUser(User user) {
        try {
            String insertUserQuery = "insert into user (username, password, role) values (?, ?, ?)";
            PreparedStatement insertUserStatement = connection.prepareStatement(insertUserQuery);
            insertUserStatement.setString(1, user.getUsername());
            insertUserStatement.setString(2, user.getPassword());
            insertUserStatement.setString(3, user.getRole());
            insertUserStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        try {
            String selectProductsQuery = "select * from product";
            PreparedStatement selectProductsStatement = connection.prepareStatement(selectProductsQuery);
            ResultSet resultSet = selectProductsStatement.executeQuery();
            while (resultSet.next()) {
                int productId = resultSet.getInt("productid");
                String productName = resultSet.getString("productname");
                String description = resultSet.getString("description");
                double price = resultSet.getDouble("price");
                int quantityInStock = resultSet.getInt("quantityinstock");
                String type = resultSet.getString("type");
                String brand = resultSet.getString("brand");
                int warrantyPeriod = resultSet.getInt("warrantyperiod");
                String size = resultSet.getString("size");
                String color = resultSet.getString("color");

                if (type.equalsIgnoreCase("Electronics")) {
                    Electronics electronics = new Electronics(productId, productName, description, price, quantityInStock,type, brand, warrantyPeriod);
                    productList.add(electronics);
                } else if (type.equalsIgnoreCase("Clothing")) {
                    Clothing clothing = new Clothing(productId, productName, description, price, quantityInStock,type, size, color);
                    productList.add(clothing);
                }
            }
        } catch (SQLException e) {
            System.out.println(e);

        }
        return productList;
    }

    @Override
    public List<Product> getOrderByUser(User user) {
        List<Product> orderedProducts = new ArrayList<>();
        try {
            String selectOrderQuery = "select p.* from product p join orders o on p.productid = o.product_id where o.user_id = ?";
            PreparedStatement selectOrderStatement = connection.prepareStatement(selectOrderQuery);
            selectOrderStatement.setInt(1, user.getUserId());
            ResultSet resultSet = selectOrderStatement.executeQuery();
            while (resultSet.next()) {
                int productId = resultSet.getInt("productid");
                String productName = resultSet.getString("productname");
                String description = resultSet.getString("description");
                double price = resultSet.getDouble("price");
                int quantityInStock = resultSet.getInt("quantityinstock");
                String type = resultSet.getString("type");
                String brand = resultSet.getString("brand");
                int warrantyPeriod = resultSet.getInt("warrantyperiod");
                String size = resultSet.getString("size");
                String color = resultSet.getString("color");

                if (type.equals("Electronics")) {
                    Electronics electronics = new Electronics(productId, productName, description, price, quantityInStock,type, brand, warrantyPeriod);
                    orderedProducts.add(electronics);
                } else if (type.equals("Clothing")) {
                    Clothing clothing = new Clothing(productId, productName, description, price, quantityInStock,type, size, color);
                    orderedProducts.add(clothing);
                }
            }
        } catch (SQLException e) {
        	System.out.println(e);
        }
        return orderedProducts;
    }

    
    public User getUserById(int userId) throws UserNotFoundException {
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        User user = null;

        try {

            String query = "select userid, username, password, role from user WHERE userid = ?";
            statement = connection.prepareStatement(query);
            statement.setInt(1, userId);

            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int id = resultSet.getInt("userid");
                String username = resultSet.getString("username");
                String password = resultSet.getString("password");
                String role = resultSet.getString("role");

                user = new User(id, username, password, role);
            } else {
                throw new UserNotFoundException("User with ID " + userId + " not found");
            }
        } catch (SQLException e) {
        	System.out.println(e);
        }
        catch (UserNotFoundException e) {
        	  System.out.println("Error: User with ID " + userId + " not found.");
      	}

        return user;
    }
    
    @Override
    public Product getProductById(int productId) {
        Product product = null;
        try {
            String query = "select * from product where productid = ?";
            
            PreparedStatement statement = connection.prepareStatement(query);
            
            statement.setInt(1, productId);
            
            ResultSet resultSet = statement.executeQuery();
            
            if (resultSet.next()) {
                int productid = resultSet.getInt("productid");
                String productName = resultSet.getString("productname");
                String description = resultSet.getString("description");
                double price = resultSet.getDouble("price");
                int quantityInStock = resultSet.getInt("quantityinstock");
                String type = resultSet.getString("type");
                String brand = resultSet.getString("brand");
                int warrantyPeriod = resultSet.getInt("warrantyperiod");
                String size = resultSet.getString("size");
                String color = resultSet.getString("color");
                
                if ("Electronics".equalsIgnoreCase(type)) {
                    product = new Electronics(productid, productName, description, price, quantityInStock, type, brand, warrantyPeriod);
                } else if ("Clothing".equalsIgnoreCase(type)) {
                    product = new Clothing(productid, productName, description, price, quantityInStock, type, size, color);
                } else {
                    System.err.println("Unknown product type: " + type);
                }
            }
        } catch (SQLException e) {
        	System.out.println(e);
        }
        return product;
    }


}
