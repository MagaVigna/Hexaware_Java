package model;


public class Electronics extends Product {
     String brand;
     int warrantyPeriod;
     
	public Electronics(int productid, String productname, String description, double price, int quantityinstock,
			String type, String brand, int warrantyPeriod) {
		super(productid, productname, description, price, quantityinstock, type);
		this.brand = brand;
		this.warrantyPeriod = warrantyPeriod;
	}

	public String getBrand() {
		return brand;
	}
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public int getWarrantyPeriod() {
		return warrantyPeriod;
	}
	
	public void setWarrantyPeriod(int warrantyPeriod) {
		this.warrantyPeriod = warrantyPeriod;
	}

	@Override
	public String toString() {
		return "Electronics [brand=" + brand + ", warrantyPeriod=" + warrantyPeriod + "]";
	}
     
     

}

