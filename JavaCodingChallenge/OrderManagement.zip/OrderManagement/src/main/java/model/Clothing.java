package model;

public class Clothing extends Product {
     String size;
     String color;
     
     public Clothing(int productid, String productname, String description, double price, int quantityinstock,
			String type, String size, String color) {
		super(productid, productname, description, price, quantityinstock, type);
		this.size = size;
		this.color = color;
     }

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public String toString() {
		return "Clothing [size=" + size + ", color=" + color + "]";
	}
 
}
