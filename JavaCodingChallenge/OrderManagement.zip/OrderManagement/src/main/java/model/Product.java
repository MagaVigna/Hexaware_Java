package model;


public class Product {
     int productid;
     String productname;
     String description;
     double price;
     int quantityinstock;
     String type;
     
	public Product(int productid, String productname, String description, double price, int quantityinstock,
			String type) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.description = description;
		this.price = price;
		this.quantityinstock = quantityinstock;
		this.type = type;
	}

	public int getProductid() {
		return productid;
	}
	
	public void setProductid(int productid) {
		this.productid = productid;
	}
	
	public String getProductname() {
		return productname;
	}
	
	public void setProductname(String productname) {
		this.productname = productname;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public int getQuantityinstock() {
		return quantityinstock;
	}
	
	public void setQuantityinstock(int quantityinstock) {
		this.quantityinstock = quantityinstock;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Product [productid=" + productid + ", productname=" + productname + ", description=" + description
				+ ", price=" + price + ", quantityinstock=" + quantityinstock + ", type=" + type + "]";
	}
     
     

}
