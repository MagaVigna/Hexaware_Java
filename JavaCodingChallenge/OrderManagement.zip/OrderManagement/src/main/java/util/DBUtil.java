package util;

import java.sql.*;

public class DBUtil {

    private static Connection conn = null;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/order_management", "root", "magavigna");
            System.out.println("Connected to the database");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static Connection getDBConn() throws SQLException {
        return conn;
    }
}
