package exception;

public class UserNotFoundException extends Exception {
	
	int userID;
	
	public UserNotFoundException(String message, int userId) {
        super(message);
        this.userID = userId;
    }
	
	public UserNotFoundException(String message) {
        super(message);
    }
	
	public int getUserId() {
        return userID;
    }
}
