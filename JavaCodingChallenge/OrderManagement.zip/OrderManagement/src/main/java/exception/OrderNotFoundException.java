package exception;

public class OrderNotFoundException extends Exception {
	
	int orderID;
	
	public OrderNotFoundException(String message, int orderID) {
        super(message);
        this.orderID = orderID;
    }
    
    public int getOrderId() {
        return orderID;
    }
}
