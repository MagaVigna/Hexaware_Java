package main;

import dao.*;
import model.*;
import exception.*;
import java.util.List;
import java.util.Scanner;

public class OrderManagement {
	
	static Scanner scanner = new Scanner(System.in);
    
    static IOrderManagementRepository orderRepo = new OrderProcessor();
    
    public static void main(String[] args) {
        
        while (true) {
        	System.out.println("Menu:");
            System.out.println("1. Create User");
            System.out.println("2. Create Product");
            System.out.println("3. Create Order");
            System.out.println("4. Cancel Order");
            System.out.println("5. Get All Products");
            System.out.println("6. Get Order by User");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    createUser();
                    break;
                case 2:
                    createProduct();
                    break;
                case 3:
                    createOrder();
                    break;
                case 4:
                    cancelOrder();
                    break;
                case 5:
                    getAllProducts();
                    break;
                case 6:
                    getOrderbyUser();
                    break;
                case 7:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void createUser() {
    	
        System.out.println("Enter user details:");
        System.out.print("Username: ");
        String username = scanner.nextLine();
        scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();
        System.out.print("Role (Admin/User): ");
        String role = scanner.nextLine();

        User user = new User(0,username, password, role);
        orderRepo.createUser(user);
        System.out.println("User created successfully!");
    }

    static void createProduct() {
    	
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); 

        try {
            User user = orderRepo.getUserById(userId);
            System.out.println("Enter product details:");
            System.out.print("Product Name: ");
            String productName = scanner.nextLine();
            System.out.print("Description: ");
            String description = scanner.nextLine();
            System.out.print("Price: ");
            double price = scanner.nextDouble();
            System.out.print("Quantity in Stock: ");
            int quantityInStock = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Type (Electronics/Clothing): ");
            String type = scanner.nextLine();

            Product product;
            if (type.equalsIgnoreCase("Electronics")) {
                System.out.print("Brand: ");
                String brand = scanner.nextLine();
                System.out.print("Warranty Period (in months): ");
                int warrantyPeriod = scanner.nextInt();
                product = new Electronics(0, productName, description, price, quantityInStock, type, brand, warrantyPeriod);
            } else if (type.equalsIgnoreCase("Clothing")) {
                System.out.print("Size: ");
                String size = scanner.nextLine();
                System.out.print("Color: ");
                String color = scanner.nextLine();
                product = new Clothing(0, productName, description, price, quantityInStock, type, size, color);
            } else {
                System.out.println("Invalid product type");
                return;
            }

            orderRepo.createProduct(user, product);
            System.out.println("Product created successfully!");
        }
        catch (UserNotFoundException e) {
            System.out.println("Error: User with ID " + e.getUserId() + " not found. Message: " + e.getMessage());
        }
    }

    private static void createOrder() {
        try {
            System.out.print("Enter User ID: ");
            int userId = scanner.nextInt();
            scanner.nextLine(); 

            User user = orderRepo.getUserById(userId);
            if (user == null) {
                System.out.println("User with ID " + userId + " does not exist.");
                return;
            }

            System.out.print("Enter Product ID: ");
            int productId = scanner.nextInt();
            scanner.nextLine(); 

            Product product = orderRepo.getProductById(productId);
            if (product == null) {
                System.out.println("Product with ID " + productId + " does not exist.");
                return;
            }

            System.out.print("Enter Quantity: ");
            int quantity = scanner.nextInt();
            scanner.nextLine(); 
            
            orderRepo.createOrder(user, product, quantity);
            System.out.println("Order created successfully!");
        } catch (UserNotFoundException | OrderNotFoundException  e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    
    private static void cancelOrder() {
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        System.out.print("Enter Order ID: ");
        int orderId = scanner.nextInt();

        try {
            orderRepo.cancelOrder(userId, orderId);
            System.out.println("Order cancelled successfully!");
        } catch (UserNotFoundException | OrderNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void getAllProducts() {
        List<Product> productList = orderRepo.getAllProducts();
        if (productList.isEmpty()) {
            System.out.println("No products available.");
        } else {
            System.out.println("List of all products:");
            for (Product product : productList) {
                System.out.println(product);
            }
        }
    }

    private static void getOrderbyUser() {
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); 
            List<Product> orderedProducts = orderRepo.getOrderByUser(new User(userId));
            if (orderedProducts.isEmpty()) {
                System.out.println("No orders found for the user.");
            } else {
                System.out.println("Orders for user with ID " + userId + ":");
                for (Product product : orderedProducts) {
                    System.out.println(product);
                }
            }
        
    }
}

